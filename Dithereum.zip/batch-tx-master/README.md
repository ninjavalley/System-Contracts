# Usage

```
node index.js sign

node index.js broadcast
```

# Modification

1) multiple signers
```
https://github.com/DithersGroup/batch-tx/blob/master/index.js#L65
```

2) concurrency 
``` 
https://github.com/DithersGroup/batch-tx/blob/master/index.js#L111
```
