# Stars-Labs
The Stars Labs is a team consisted of innovative talents from worldwide top universities, which enjoys a good reputation in Ethereum ecology, Layer2, zero knowledge proof, privacy computing, cross-chain bridge, etc.

Stars Labs is dedicated to leading the industry in the most challenging  fields. Currently Stars Labs is responsible for the product & development of Dithereum chain, on-chain governance and Layer2 DEX.