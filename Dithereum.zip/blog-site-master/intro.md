# Xingchen Lab Introduction
Xingchen Lab is composed of innovative talents from top universities at home and abroad. It has a high reputation in the frontier fields of Ethereum ecology, Layer2, zero-knowledge proof, privacy computing, and cross-chain bridges, and is committed to leading the way in the most challenging technical fields. Sexual industry results.

At present, he is mainly responsible for business including Dithereum production and research, on-chain governance infrastructure construction and Layer2 DEX.

