Using docsify to host this site.

```
npm i docsify-cli -g
docsify serve ./
```