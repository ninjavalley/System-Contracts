This is a test for HomesteadToDao, checking if the 
DAO-transition works

Example: 
```
./statet8n --input.alloc=./testdata/7/alloc.json  --input.txs=./testdata/7/txs.json --input.env=./testdata/7/env.json --output.alloc=stdout --state.fork=HomesteadToDaoAt5
```