## DITHEREUM Chain token factory contracts

A tokenFactory.sol is deployed on Dithereum mainnet to issue and manage token.

token factory address : [0x07725f3C5b34aA7a9dF1F4Fe87d673c50448e618](https://scan.ditherschain.com/address/0x07725f3C5b34aA7a9dF1F4Fe87d673c50448e618#transactions)