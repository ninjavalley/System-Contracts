Using docsify to host this site.

```
npm i docsify-cli -g
docsify serve ./
```

Welcome to the DITHEREUM Chain Docs Site。

Resources list：

### [Testnet Info](testnet.md)

### Tech Support And Help

find us via suppport emmail, or social media.
<DevContacts@dithereumchain.com>
