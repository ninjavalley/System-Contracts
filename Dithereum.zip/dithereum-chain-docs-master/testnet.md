# Testnet Info

## chainid
```
256
```
## rpc
```
https://http-testnet.dithereumchain.com
wss://ws-testnet.dithereumchain.com
```

## explorer
```
https://scan-testnet.dithereumchain.com
```

## faucet

```
https://scan-testnet.dithereumchain.com/faucet
```