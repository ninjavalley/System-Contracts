# 概述

Wallet connect enable App wallet connect to DApp via QRCode or Deeplink.

When using this protocol the most critical modification in the Wallet and DApp is supporting Dithereum networs.

例如：

# Wallet app：

https://github.com/stars-labs/walletconnect-test-wallet/commit/787c481032a9c8e4dec324f0a7529fc2775220b8

# DApp app：

https://github.com/stars-labs/walletconnect-example-dapp/commit/b427419bfb893c060b7693d2e56e6d3f703d2984