# gasprice suggestion based on txpool

3 levels: slow, medium, fast；

```
curl https://tc.dithereumchain.com/price/prediction
```


```
{
    "code": 0,
    "prices": {
        "fast": 29,
        "median": 1,
        "low": 1
    }
}
```