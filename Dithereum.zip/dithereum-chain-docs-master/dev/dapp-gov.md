# DApp Governance

## Snapshot

https://snapshot.page/#/

dapp developer: create space with metamask, choose dithereum chain;

user: create proposal in space; 

user: vote for the proposal


ref:

https://docs.snapshot.page/